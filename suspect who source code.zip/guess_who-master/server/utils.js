const getRandomArbitrary = (min, max) => Math.random() * (max - min) + min;

const Util = { getRandomArbitrary };
module.exports = Util;
