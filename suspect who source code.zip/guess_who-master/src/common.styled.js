import styled from "styled-components";

export const CustomImage = styled("img")`
  height: 100%;
  width: 100%;
`;
