export const SOCKET_END_POINT = "http://localhost:8080";
export const API_END_POINT = `${SOCKET_END_POINT}/api`;
